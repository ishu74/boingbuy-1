import iphone14 from "./images/iPhone14.jpg"
import GalaxyS23 from "./images/GalaxyS23.jpg"
import Pixel8 from "./images/Pixel8.jpg"
import OnePlus11 from "./images/OnePlus11.jpg"
import MacBook_Pro from "./images/MacBookPro.jpg"
import Dell_XPS_13 from "./images/DellXPS13.jpg"
import HP_Spectre_x360 from "./images/HPSpectrex360.jpg"
import Lenovo_ThinkPad_X1 from "./images/LenovoThinkPadX1.jpg"
import Slim_Fit_Shirt from "./images/SlimFitShirt.jpg"
import Chino_Pants from "./images/ChinoPants.jpg"
import Denim_Jacket from "./images/DenimJacket.jpg"
import Sneakers from "./images/Sneakers.jpg"
import Evening_Gown from "./images/EveningGown.jpg"
import Summer_Dress from "./images/SummerDress.jpg"
import High_Heels from "./images/HighHeels.jpg"
import Leather_Bag from "./images/LeatherBag.jpg"
import Blender from "./images/Blender.jpg"
import Toaster from "./images/Toaster.jpg"
import Microwave_Oven from "./images/MicrowaveOven.jpg"
import Dishwasher from "./images/Dishwasher.jpg"
import Washing_Machine from "./images/WashingMachine.jpg"
import Dryer from "./images/Dryer.jpg"
import Iron from "./images/Iron.jpg"
import Garment_Steamer from "./images/GarmentSteamer.jpg"
import The_Great_Gatsby from "./images/TheGreatGatsby.jpg"
import Book1984 from "./images/Book1984.jpg"
import To_Kill_a_Mockingbird from "./images/ToKillaMockingbird.jpg"
import The_Catcher_in_the_Rye from "./images/TheCatcherintheRye.jpg"
import Sapiens from "./images/Sapiens.jpg"
import Becoming from "./images/Becoming.jpg"
import Educated from "./images/Educated.jpg"
import The_Power_of_Habit from "./images/ThePowerofHabit.jpg"
import Mountain_Bike from "./images/MountainBike.jpg"
import Tent from "./images/Tent.jpg"
import Sleeping_Bag from "./images/SleepingBag.jpg"
import Hiking_Boots from "./images/HikingBoots.jpg"
import Treadmill from "./images/Treadmill.jpg"
import Dumbbell_Set from "./images/DumbbellSet.jpg"
import Yoga_Mat from "./images/YogaMat.jpg"
import Resistance_Bands from "./images/ResistanceBands.jpg"







export const image = {
    "iphone14": iphone14,
    "galaxy_s23": GalaxyS23,
    "pixel_8": Pixel8,
    "OnePlus_11": OnePlus11,
    "MacBook_Pro": MacBook_Pro,
    "Dell_XPS_13": Dell_XPS_13,
    "HP_Spectre_x360":HP_Spectre_x360,
    "Lenovo_ThinkPad_X1" :Lenovo_ThinkPad_X1,
    "Slim_Fit_Shirt":Slim_Fit_Shirt,
    "Chino_Pants":Chino_Pants,
    "Denim_Jacket":Denim_Jacket,
    "Sneakers":Sneakers,
    "Evening_Gown":Evening_Gown,
    "Summer_Dress":Summer_Dress,
    "High_Heels":High_Heels,
    "Leather_Bag":Leather_Bag,
    "Blender":Blender,
    "Toaster":Toaster,
    "Microwave_Oven":Microwave_Oven,
    "Dishwasher":Dishwasher,
    "Washing_Machine":Washing_Machine,
    "Dryer":Dryer,
    "Iron":Iron,
    "Garment_Steamer":Garment_Steamer,
    "The_Great_Gatsby":The_Great_Gatsby,
    "Book1984":Book1984,
    "To_Kill_a_Mockingbird":To_Kill_a_Mockingbird,
    "The_Catcher_in_the_Rye":The_Catcher_in_the_Rye,
    "Sapiens":Sapiens,
    "Becoming":Becoming,
    "Educated":Educated,
    "The_Power_of_Habit":The_Power_of_Habit,
    "Mountain_Bike":Mountain_Bike,
    "Tent":Tent,
    "Sleeping_Bag":Sleeping_Bag,
    "Hiking_Boots":Hiking_Boots,
    "Treadmill":Treadmill,
    "Dumbbell_Set":Dumbbell_Set,
    "Yoga_Mat":Yoga_Mat,
    "Resistance_Bands":Resistance_Bands




    








    

    



};