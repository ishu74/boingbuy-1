const log = (message) => {
    console.log('Console Logger:', message);
  };
  
  export default log;
  