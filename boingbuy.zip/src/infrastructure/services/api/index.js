import apiCart from "./apiCart";

export default {
    apiCart
}