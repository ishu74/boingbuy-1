export const setOrders = (orders) => ({
    type: 'SET_ORDERS',
    payload: orders,
  });
  
  export const addOrder = (order) => ({
    type: 'ADD_ORDER',
    payload: order,
  });
  